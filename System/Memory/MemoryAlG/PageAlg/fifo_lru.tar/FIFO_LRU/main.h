int lru();
int fifo();
