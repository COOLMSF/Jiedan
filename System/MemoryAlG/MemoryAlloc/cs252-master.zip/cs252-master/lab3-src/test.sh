echo Hello
setenv HELLO WORLD
printenv
