#!/bin/sh

sudo rmmod charDev
sudo rm /dev/charDev
