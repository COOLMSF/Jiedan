1. 把Makefile文件里KERNELDIR对应的路径改成/usr/src下的linux内核文件夹路径
2. make编译