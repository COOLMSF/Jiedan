Description:
This is an example of linux device driver.

Build:
1. Build your linux kernel tree
2. Configure correct linux kernel source path in Makefile
3. Build the module
4. Install the module
5. Build the test program in test directory
6. Run the test program
7. Remove the module from your system
