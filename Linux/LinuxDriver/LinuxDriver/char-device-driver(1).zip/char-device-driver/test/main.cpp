#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>

#define DEVICE_FILE "/dev/chardev0"

int main() {
    int file;
    int returnval;
    char buff[8];
    printf("open file\n");
    file = open(DEVICE_FILE, O_RDWR);
    printf("file opened\n");

    if (file < 0) {
        _exit(1);
    }

    returnval = write(file, "abcde", 5);
    printf("Write: %d\n", returnval);

    printf("Read: %d\n", returnval);
    printf("Content: ");
    returnval = read(file, buff, returnval);
    for (int i = 0; i < returnval; i++)
    {
        putchar(buff[i]);
    }
    putchar('\n');

    close(file);

    return 0;
}
