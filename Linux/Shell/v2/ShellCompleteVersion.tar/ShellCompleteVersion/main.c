/* Main function begins here */

#include "allheaders.h"
#include "shell.h"

int
main()
{
    int status;
    char new_line = 0;

    system ("clear");
    signal(SIGINT, sigintHandler);
    using_history();

    do {

	char buffer[1024] = { 0 };
        clear_variables();
	char *p_input_buffer;
	char *p_temp;
	char *p_ex;
	int index = 0;
        shell_prompt();
        input_buffer = readline (prompt);

	// if command contains run command, should use it background
	p_ex = strstr(input_buffer, "run");
	p_temp = input_buffer;
	if (p_ex != NULL) {
	while (p_temp != p_ex) {
		index++;
		p_temp++;
	}
	strncat(buffer, input_buffer, index);
	// 3 is strlen of "run"
	strcat(buffer, input_buffer + index + 3);
	// if run found, append & to command
	strcat(buffer, " &");

	input_buffer = buffer;
	}

	// filter run
	

        if (!(strcmp(input_buffer, "\n") && strcmp(input_buffer,"")))
            continue;

        if (!(strncmp(input_buffer, "exit", 4) && strncmp(input_buffer, "quit", 4))) {

            flag = 1;
            break;
        }

        tokenize_by_pipe();

        if (bckgrnd_flag == 0)
            waitpid(pid,&status,0);
        else
            status = 0;

    } while(!WIFEXITED(status) || !WIFSIGNALED(status));

    if (flag == 1) {

        printf("\nClosing Shell\n");
        exit(0);
    }

    return 0;
}
