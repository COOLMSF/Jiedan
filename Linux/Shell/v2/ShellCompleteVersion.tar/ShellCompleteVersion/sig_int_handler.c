#include "allheaders.h"

/* This function handles the interrupt signals */

void
sigintHandler(int sig_num)
{
    signal(SIGINT, sigintHandler);
    fflush(stdout);
}
