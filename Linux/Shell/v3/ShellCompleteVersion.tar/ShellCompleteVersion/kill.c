#include <sys/types.h>
#include <signal.h>

int builtin_kill(int pid)
{
	kill(pid, 9);
}
