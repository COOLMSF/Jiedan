#include "allheaders.h"

int list_dir(char *cmd) 
{
    DIR *d;
    char *path = ".";
    struct dirent *dir;

    d = opendir(path);
    char full_path[1000];
    if (d)
    {
	    int counter = 0;
        while ((dir = readdir(d)) != NULL)
        {
                printf("%15s",dir->d_name);
		printf("\n");
        }
        closedir(d);
    }
}
