#include "CLExecutiveCommunication.h"

CLExecutiveCommunication::CLExecutiveCommunication()
{
}

CLExecutiveCommunication::~CLExecutiveCommunication()
{
}

