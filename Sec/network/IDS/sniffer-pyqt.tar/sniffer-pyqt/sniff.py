# This Python file uses the following encoding: utf-8
import sys
# from Pyqt5 import QApplication, QMainWindow

from PyQt5 import QtCore,QtGui,QtWidgets
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
class sniff(QMainWindow):
    def __init__(self):
        QMainWindow.__init__(self)


# if __name__ == "__main__":
#     app = QApplication([])
#     window = sniff()
#     window.show()
#     sys.exit(app.exec_())
