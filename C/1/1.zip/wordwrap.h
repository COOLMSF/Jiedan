#ifndef TEXT_WORDWRAP_H
#define TEXT_WORDWRAP_H

#include <string>
using namespace std;//Specify identifiers directly (global variables)

void initWordWrap();
void wrapOut(const string *text);
void wrapEndPara();


#endif //TEXT_WORDWRAP_H
