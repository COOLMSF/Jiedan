#include "stu.h"
int main()
{
    int nChoose1;
    int nChoose2;
    int nChoose3;
    int nChoose4;
    int nEnd = 1;
    int nEnd2 = 1;
    int nEnd3 = 1;
    char sName[20];
    char sPassword[20];
    //choice����ѡ�������ִ�в���,iѭ��,a������ѡ��//
    stu* x;
    x = NULL;
    while (nEnd)
    {

        nChoose1 = MainMenu();
        switch (nChoose1)
        {
        case 0:
            nEnd = 0;
            sort(x);                //����
            outfile(x);               //����������д���ļ�
            system("cls");               //����
            printf("         \n        л     л     ʹ     ��     !!!     \n");
            break;
        case 1:
            printf("�����븨��Ա�˺ţ�\n");
            scanf("%s", sName);
            printf("���������룺\n");
            scanf("%s", sPassword);
            if (strcmp(sName, "admin") != 0)
            {
                printf("�˺Ŵ���\n");
            }
            else
            {
                if (strcmp(sPassword, "12345") != 0)
                {
                    printf("�������\n");
                }
                else
                {
                    nEnd2 = 1;
                    while (nEnd2)
                    {
                        nChoose2 = ManageMenu();
                        switch (nChoose2)
                        {
                        case 1:
                            x = creatlink(x);
                            break;
                        case 2:
                            x = modify(x);
                            break;
                        case 3:
                            x = delet(x);
                            break;

                        case 4:
                            nChoose4 = FindMenu();
                            switch (nChoose4)
                            {
                            case 1:
                                findNum(x);
                                break;
                            case 2:
                                findName(x);
                                break;
                            default:
                                printf(" ѡ�����벻��ȷ���޷�ִ�С�\n");
                                break;
                            }
                            break;
                        case 5:
                            insert(x);
                            break;
                        case 6:
                            print(x);
                            break;
                        case 7:
                            x = sort(x);
                            break;
                        case 0:
                            nEnd2 = 0;
                            break;
                        default:
                            printf(" ѡ�����벻��ȷ���޷�ִ�С�\n");
                            break;
                        }
                    }
                }
            }
            break;
        case 2:
            nEnd3 = 1;
            while (nEnd3)
            {
                nChoose3 = StudentMenu();
                switch (nChoose3)
                {
                case 0:
                    nEnd3 = 0;
                    break;
                case 1:
                    nChoose4 = FindMenu();
                    switch (nChoose4)
                    {
                    case 1:
                        findNum(x);
                        break;
                    case 2:
                        findName(x);
                        break;
                    default:
                        printf(" ѡ�����벻��ȷ���޷�ִ�С�\n");
                        break;
                    }
                    break;
                default:
                    printf("ѡ�����벻��ȷ���޷�ִ�С�\n");
                    break;
                }
            }
            break;
        default:
            printf("ѡ�����벻��ȷ���޷�ִ�С�\n");
            break;
        }
    }
    return 0;
}




