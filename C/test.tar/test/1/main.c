#include <stdio.h>

int sort(double *arr, int size);
int swap(double *a, double *b);

int main()
{
    double arr[3] = { 0 };

    puts("请输入a，b，c：");
    for (int i = 0; i < 3; i++) {
        scanf("%lf", arr+i);
    }

    sort(arr, 3);
    for (int i = 0; i < 3; i++) {
        printf("%lf ", arr[i]);
    }

}

int sort(double *arr, int size)
{
    for (int i = 0; i < size - 1; i++) {
        if (arr[i] < arr[i+1]) {
            swap(arr+i, arr+i+1);
        }
    }
}

int swap(double *a, double *b)
{
    double temp;

    temp = *a;
    *a = *b;
    *b = temp;
}

