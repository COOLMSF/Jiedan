#include <stdio.h>

#define MAX_STR 255
#define MAX_SCORE_ELE 3
#define MAX_STU_ELE 5

struct _Student {
    int id;
    char name[MAX_STR];
    double score[MAX_SCORE_ELE];
    double total_score;
    double avg_score;
};

void save_file(FILE *fp, struct _Student *stu_arr_ptr, int size)
{
    for (int i = 0; i < size; i++) {
        fprintf(fp, "ID:%d\t姓名:%s\t总分:%lf平均分:%lf\n", stu_arr_ptr[i].id, stu_arr_ptr[i].name, stu_arr_ptr[i].total_score, stu_arr_ptr[i].avg_score);
    }
}
void print_info(struct _Student *stu_arr_ptr, int size)
{
    for (int i = 0; i < size; i++) {
        printf("ID:%d\t姓名:%s\t总分:%lf\n", stu_arr_ptr[i].id, stu_arr_ptr[i].name, stu_arr_ptr[i].total_score);
    }
}
int main()
{
    FILE *fp = NULL;
    char filename[MAX_STR] = { 0 };
    struct _Student stu_arr[MAX_STU_ELE];
    struct _Student *stu_arr_ptr = stu_arr;

    for (int i = 0; i < MAX_STU_ELE; i++) {
        printf("请输入第%d个学生的信息(id, 姓名，分数):", i + 1);
        scanf("%d %s", &stu_arr[i].id, stu_arr[i].name);

        printf("请输入学生成绩:");
        double total_score = 0.0;
        for (int j = 0; j < MAX_SCORE_ELE; j++) {
            scanf("%lf", &stu_arr[i].score[j]);
            total_score += stu_arr[i].score[j];
        }
        stu_arr[i].total_score = total_score;
        stu_arr[i].avg_score = total_score / MAX_SCORE_ELE;
    }

    print_info(stu_arr_ptr, MAX_STU_ELE);

    // puts("请输入要保存的文件:");
    // scanf("%s", filename);
    fp = fopen("stud.txt", "w");
    if (fp == NULL) {
        perror("fopen");
    }
    save_file(fp, stu_arr_ptr, MAX_STU_ELE);
    puts("保存到文件成功");
}
 
