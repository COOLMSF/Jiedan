#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MAX_STR 255

int main()
{
    int c;
    int n = 0;
    FILE *fp = NULL;
    char buf[MAX_STR] = { 0 };
    char buf_num[MAX_STR] = { 0 };
    char filename[MAX_STR] = { 0 };

    puts("请输入数据，以#结束:");
    while ((c = getchar()) != '#') {
        buf[n] = c;
        n++;
    }

    puts("请输入文件名:");
    scanf("%s", filename);
    fp = fopen(filename, "w");

    sprintf(buf_num, "%d", n);
    strcat(buf, "  ");
    strcat(buf, buf_num);
    fprintf(fp, "%s", buf);
    fclose(fp);
}
