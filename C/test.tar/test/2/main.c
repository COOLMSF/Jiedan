#include <stdio.h>

int swap(int *a, int *b)
{
    int temp;

    temp = *a;
    *a = *b;
    *b = temp;
}

int reverse_arr(int *arr, int size)
{
    for (int i = 0; i < size / 2; i++) {
        swap(&arr[i], &arr[size - i - 1]);
    }
}

int main()
{
    int arr[5] = { 0 };

    puts("请输入5个数据:");
    for (int i = 0; i < 5; i++) {
        scanf("%d", arr + i);
    }

    puts("逆序后:");
    reverse_arr(arr, 5);
    for (int i = 0; i < 5; i++) {
        printf("%d ", arr[i]);
    }
}

