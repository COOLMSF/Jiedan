#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>
#include <errno.h>
#include <locale.h>
 
int main(void)
{
    setlocale(LC_ALL, "en_US.utf8");
    FILE *fp = fopen("/dev/stdin", "r");
    if(!fp) {
        perror("Can't open file for reading");
        return EXIT_FAILURE;
    }

    wint_t wc;
    int cnt = 0;
    errno = 0;
    while ((wc = fgetwc(fp)) != WEOF) {
        // putwchar(wc);
        cnt++;
    }
 
    if (ferror(fp)) {
        if (errno == EILSEQ) {
            puts("Invalid or incomplete multibyte or wide character");
            return -1;
        }
        else {
            puts("Invalid or incomplete multibyte or wide character");
            return -1;
        }
    }
    printf("%d", cnt);
 
    fclose(fp);
}
