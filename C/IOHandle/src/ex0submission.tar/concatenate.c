#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

void cat(const char *filename)
{

    FILE *fp = fopen(filename, "r");
    if (fp == NULL) {
        perror("fopen");
        exit(EXIT_FAILURE);
    }
    // This will cause some problem
    // while (1) {
    //     int ret;
    //     ret = fread(buf, BUFSIZ, 1, fp) ;
    //     if (ret < 0 || feof(fp))
    //       return;
    //     fwrite(buf, BUFSIZ, 1, stdout);
    // }

    // Will caues problem when handling 0x00
    // const size_t line_size = 300;
    // char* line = malloc(line_size);
    // while (fgets(line, line_size, fp) != NULL)  {
    //     printf(line);
    // }
    // free(line);    // dont forget to free heap memory

    // can get all passed, but slow, no buffer use
    while (1) {
      char c;
      int ret;

      ret = fread(&c, 1, 1, fp);
      if (ret < 0) {
        perror("fread");
        exit(EXIT_FAILURE);
      }
      if (feof(fp))
        break;
      else
        // fwrite(buf, BUFSIZ, 1, stdout);
        // printf("%s", buf);
        putchar(c);
    }
    

}

void check_file_type(const char *filename)
{
    int status;
    struct stat fs;
    char tmp_name[BUFSIZ] = { 0 };

    status = stat(filename, &fs);
    if( status == -1 ) {
        fprintf(stderr,"File error\n");
        exit(1);
    }

    if (strcmp(filename,"/dev/stdin") == 0)
        strcpy(tmp_name, "standard input");
    else
        strcpy(tmp_name, filename);

    /* file permissions are kept in the st_mode member */
    /* The S_ISREG() macro tests for regular files */

    /* should be sent to error stream */
    if (S_ISREG(fs.st_mode))
        fprintf(stderr, "%s is a regular file\n", tmp_name);
    else if (S_ISFIFO(fs.st_mode))
        fprintf(stderr, "%s is a pipe\n", tmp_name);
    else if (S_ISCHR(fs.st_mode))
        fprintf(stderr, "%s is a character device\n", tmp_name);
    else
        fprintf(stderr, "is something else");
}

int main(int argc, char *argv[])
{
    const char *filename;

    if (argc < 2) {
        filename = "/dev/stdin";
        check_file_type(filename);
        cat(filename);
    } else {
        for (int i = 1; i < argc; ++i) {
          if (strcmp(argv[i], "-") == 0)
              filename = "/dev/stdin";
          else
              filename = argv[i];

            check_file_type(filename);
            cat(filename);
        }
    }
    return(0);
}
