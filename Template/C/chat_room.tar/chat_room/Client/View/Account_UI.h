#ifndef _ACCOUNT_UI_H
#define _ACCOUNT_UI_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int Account_UI_SignIn();

int Account_UI_Login();

void Account_UI_ChInfo();

void Account_UI_Password();

#endif
