#ifndef _MAIN_UI_H
#define _MAIN_UI_H

void Main_UI_Hello();

void Main_UI_Menu();
#endif
