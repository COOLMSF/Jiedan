#ifndef _FRIENDS_UI_H
#define _FRIENDS_UI_H

void Friends_UI_ShowList();

void Friends_UI_Add();

void Friends_UI_Apply();

void Friends_UI_ShowApply();

//void Fr

#endif
