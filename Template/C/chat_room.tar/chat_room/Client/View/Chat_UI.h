#ifndef _CHAT_UI_H
#define _CHAT_UI_H

void Chat_UI_Private();

void Chat_UI_Group();

#endif
