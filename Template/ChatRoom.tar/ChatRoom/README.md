# ChatRoom
Easy ChatRoom in Linux

![Screenshot](screenshot.png)

Compile:

gcc chatroom_client.c -o client -lclient -lpthread -L.

gcc chatroom_server.c -o server -lserver -lpthread -L.
