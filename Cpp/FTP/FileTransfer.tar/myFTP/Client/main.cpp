#pragma comment(lib,"ws2_32.lib")

#include "Client.h"


void main()
{
	Client client;
	client.running();
	system("pause");

}
