#include "matrix.h"

using namespace std;

int main() 
{
    cout << "欢迎使用矩阵系统\n";
    cout << "1) 创建2个任意矩阵\n";
    cout << "2) 从文件读取数据相乘\n";

    int input;
    
    while (1) {
        cin >> input;
        int j, k, j1, k1;
        cout << "欢迎使用矩阵系统\n";
        cout << "1) 创建2个任意矩阵\n";
        cout << "2) 从文件读取数据相乘\n";

        if (input == 1) {
            int cnt = 0;
            cout << "输入矩阵1的大小j, k:";
            cin >> j;
            cin >> k;
            cout << "输入矩阵2的大小j1, k1:";
            cin >> j1;
            cin >> k1;

            Matrix<double> a(j, k);
            Matrix<double> b(j1, k1);

            // fill matrix
            cout << "[+] fill data for matrix A\n";
            for (int i = 0; i < j; i++) {
                for (int j = 0; j < k; j++) {
                    a.put(i, j, cnt);
                    cnt++;
                }
            }
            cout << "[+] fill data for matrix A done\n";

            cout << "[+] fill data for matrix B\n";
            for (int i = 0; i < j1; i++) {
                for (int j = 0; j < k1; j++) {
                    b.put(i, j, 2);
                }
            }
            cout << "[+] fill data for matrix B done\n";

            cout << "[+] multiply A and B\n";
            Matrix<double> c = a * b;

            for (int i = 0; i < c.getHeight(); i++) {
                for (int j = 0; j < c.getWidth(); j++) {
                    cout << c.get(i, j) << " ";
                }
                cout << "\n";
            }
        } else if (input == 2) {
            Matrix<double> a(3, 4);
            Matrix<double> b(3, 4);
            Matrix<double> c(3, 4);

            cout << "[+] read from file\n";
            a.putFromFile(3, 4, "double1.txt");
            cout << "[+] read from file done\n";
            cout << "[+] read from file\n";
            b.putFromFile(3, 4, "double2.txt");
            cout << "[+] read from file done\n";

            cout << "[+] multiply done\n";
            c = a * b;

            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 4; j++) {
                    cout << c.get(i, j) << " ";
                }
                cout << "\n";
            }
        } else {
            cout << "输入错误";
            exit(EXIT_FAILURE);
        }
    }


}
