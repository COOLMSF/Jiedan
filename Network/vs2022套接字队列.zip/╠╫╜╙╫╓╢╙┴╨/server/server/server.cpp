﻿#undef UNICODE

#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <time.h>
#include <thread>
#include <string>
#include <vector>
#include <queue>

using namespace std;

// Person类（struct），代表一个人
class Person {
private:
    // 姓名
    string name;
    // 位次号
    int num;
public:
    // 构造函数
    Person(string name, int num)
    {
        this->name = name;
        this->num = num;
    };

     // 获取位次号
    int get_num()
    {
        return this->num;
    };

     // 获取姓名
    string get_name()
    {
        return this->name;
    }
};

// person队列
queue<Person> person_queue;


// Need to link with Ws2_32.lib
#pragma comment (lib, "Ws2_32.lib")
// #pragma comment (lib, "Mswsock.lib")

// 默认缓冲区大小
#define DEFAULT_BUFLEN 512

// 默认socket通信地址
#define DEFAULT_ADDR "127.0.0.1"

// 默认端口号
const int DEFAULT_PORT = 12057;

// 当前时间
time_t current;
char timebuff[26];

// 初始化
SOCKET ListenSocket = INVALID_SOCKET;
SOCKET ClientSocket = INVALID_SOCKET;

// 初始化变量
bool otherClosed = false;
bool selfClosed = false;


string INFO = "[sever] ";

// 发送消息函数
void sendmsg() {
    // 无限循环，一直等待消息发送
    while (true) {
        char* s = new char[50];
        string ss;
        // 从键盘上面获取一行数据
        getline(cin, ss);

        // 字符串拷贝
        strcpy(s, ss.c_str());
        const char* str = s;

        // 输出菜单信息
        puts("0:) 退出");
        puts("1:) 出队");

        // 输入判断
        if (s[0] == '0') {
            // 如果是对方关闭链接
            if (otherClosed == true) {
                printf("You have closed the diolague!");
                break;
            }

            // 发送到客户端
            send(ClientSocket, str, strlen(str) + sizeof(char), NULL);
            printf("You have closed the diolague!");
            selfClosed = true;
            break;
        }

        char tmp_str[1024];


        // 如果选项是出队
        if (s[0] == '1') {
            // 获取队列中最前面的元素
            Person tmp = person_queue.front();

            // 移除队列中第一个元素
            person_queue.pop();

            // 格式化输出，结果输出到tmp_str
            sprintf(tmp_str, "%s已出队，位次为:%d，当前队列长度为:%d\n", tmp.get_name().c_str(), tmp.get_num(), person_queue.size());

            // 将结果发送到客户端
            send(ClientSocket, tmp_str, strlen(tmp_str), NULL);
        }
        // send(ClientSocket, str, strlen(str) + sizeof(char), NULL);
        cout << INFO;
    }
}

// 接收数据
void recvmsg() {
    while (true) {
        // 初始话
        char szBuffer[50] = { "00000000000000000000000" };

        // 从客户端结束数据
        recv(ClientSocket, szBuffer, MAXBYTE, NULL);

        // 如果从客户端接收到0, 0就是退出程序
        if (szBuffer[0] == '0') {
            if (selfClosed == false) {
                printf("The other has closed the diolague!");
                printf("please print '0' to exit!");
                otherClosed = true;
            }
            // 发送数据
            send(ClientSocket, "0", strlen("0") + sizeof(char), NULL);
            break;
        }
        
        // 如果是1，那就是入队
        if (szBuffer[0] == '1') {
            // 获取客户端的姓名
            recv(ClientSocket, szBuffer, MAXBYTE, NULL);

            // 姓名检查
            if (strlen(szBuffer) < 0) {
                cout << "客户端名字有误" << endl;
            }
            
            // 构造Person对象
            Person tmp = Person(szBuffer, person_queue.size());
            // 加入到队列中
            person_queue.push(tmp);

            cout << "正在入队" << endl;

            char data_to_send[1024];
            // 格式化输出
            sprintf(data_to_send, "队列长度为%d, 当前位次为%d\n", person_queue.size(), tmp.get_num());
            
            // 发送到客户端
            send(ClientSocket, data_to_send, strlen(data_to_send), NULL);
        }
        cout << "Message form client: " << szBuffer << endl << INFO;
    }
}

int main() {

    WSADATA wsaData;
    int iResult;

    // 存储IP和端口号，以及协议号的数据结构
    struct sockaddr_in sockAddr;
    
    // system("mode con cols=60 lines=20");

    // Print time
    // 获取当前时间戳
    current = time(&current);

    // 转化为标准时间
    ctime_s(timebuff, sizeof timebuff, &current);
    
    // 输出时间
    printf("%s", timebuff);

    // Initialize Winsock
    // windows socket address
    // 初始化windows套接字
    iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
    // 如果初始化失败
    if (iResult != 0) {
        printf("WSAStartup failed with error: %d\n", iResult);
        return 1;
    }

    // Create a SOCKET for connecting to server
    // 创建套机字，PF_INET指定IP协议，SOCK_STREAM指定TCP协议
    ListenSocket = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);\

    // 如果创建套接字失败
    if (ListenSocket == INVALID_SOCKET) {
        printf("socket failed with error: %ld\n", WSAGetLastError());
        WSACleanup();
        return 1;
    }

    // Sever Info
    // 清空内存，初始化
    memset(&sockAddr, 0, sizeof(sockAddr));

    // 使用IP协议
    sockAddr.sin_family = PF_INET;
    // sin_addr就是IP地址, ient_addr将字符串的IP地址，转化为二进制的IP地址
    sockAddr.sin_addr.s_addr = inet_addr(DEFAULT_ADDR);

    // htons, host to network，因为一般的PC机器使用的小端存储，而网络是用的大端存储，所以这里需要转化一下
    // 现在有一个整数12345, 小端存储是54321, 大端就是12345
    sockAddr.sin_port = htons(DEFAULT_PORT);

    // Allow Broadcast
    int so_broadcast = TRUE;
    // 开启广播
    iResult = setsockopt(ClientSocket, SOL_SOCKET, SO_BROADCAST, (char*)&so_broadcast, sizeof(so_broadcast));

    // Binding a Socket
    // 绑定套接字
    iResult = bind(ListenSocket, (SOCKADDR*)&sockAddr, sizeof(SOCKADDR));

    // 绑定失败
    if (iResult == SOCKET_ERROR) {
        printf("bind failed with error: %d\n", WSAGetLastError());
        closesocket(ListenSocket);
        WSACleanup();
        return 1;
    }
    cout << INFO << "Setup successfully\n" << INFO;

    // Listening on a Socket
    // 设置最多有几个客户端
    iResult = listen(ListenSocket, SOMAXCONN);

    // 设置失败
    if (iResult == SOCKET_ERROR) {
        printf("listen failed with error: %d\n", WSAGetLastError());
        closesocket(ListenSocket);
        WSACleanup();
        return 1;
    }
    cout << "Listening on a Socket...\n" << INFO;

    // Accept a Connection
    SOCKADDR clntAddr;
    int nSize = sizeof(SOCKADDR);

    // 等待客户端的链接
    ClientSocket = accept(ListenSocket, (SOCKADDR*)&clntAddr, &nSize);

    // 等待失败
    if (ClientSocket == INVALID_SOCKET) {
        printf("accept failed with error: %d\n", WSAGetLastError());
        closesocket(ListenSocket);
        WSACleanup();
        return 1;
    }

    // Send and Receive
    // 开启线程接受消息
    thread t2(recvmsg);

    // 开启线程发送消息
    thread t1(sendmsg);

    // 等待线程结束
    t1.join();
    t2.join();

    //Close
    closesocket(ClientSocket);
    closesocket(ListenSocket);
    WSACleanup();

    return 0;
}