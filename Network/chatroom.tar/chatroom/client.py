#!/bin/python
#DEVELOPED BY DEVILMASTER

import sys, time, socket, threading, os

os.system('clear')

class colors:
    blue = '\033[94m'
    cyan = '\033[96m'
    green = '\033[92m'
    red = '\033[31m'
    pink = '\033[35m'


banner = colors.cyan + """
"""


def slowprint(s):
    print(s)


print(banner)
slowprint(colors.pink + "正在连接服务器..." )
slowprint(colors.green + "成功连接到服务器...")
nickname = input(colors.blue + "[+] 输入你的昵称: ")

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server = '127.0.0.1'
port = 4444
client.connect((server, port))


def receive():
    while True:
        try:
            message = client.recv(1024).decode('ascii')
            if message == 'nickname':
                client.send(nickname.encode('ascii'))
            else:
                print(message)
        except:
            slowprint(bcolor.red + "[ERROR] An error occured!")
            client.close()
            break


def write():
    while True:
        message = '[{}] >> {}'.format(nickname, input(''))
        client.send(message.encode('ascii'))


receive_thread = threading.Thread(target=receive)
receive_thread.start()
write_thread = threading.Thread(target=write)
write_thread.start()

